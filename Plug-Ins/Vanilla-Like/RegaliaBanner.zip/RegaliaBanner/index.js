/**
* @author kye
* @link https://github.com/kyewyve/Geppetto
*/

(() => {
	const BANNER_LIST = [
		{
			file: 'arcanefracturedjinxbanner.accessories_14_24.png',
			name: 'Arcane Fractured Jinx Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/arcanefracturedjinxbanner.accessories_14_24.png'
		},
		{
			file: 'bee2023.png',
			name: 'Blue Essence Emporium 2023 Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/bee2023.png'
		},
		{
			file: 'bronze.png',
			name: 'Bronze',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/bronze.png'
		},
		{
			file: 'challenger.png',
			name: 'Challenger',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/challenger.png'
		},
		{
			file: 'default.png',
			name: 'Default',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/default.png'
		},
		{
			file: 'diamond.png',
			name: 'Diamond',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/diamond.png'
		},
		{
			file: 'emerald.png',
			name: 'Emerald',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/emerald.png'
		},
		{
			file: 'exaltedsett.accessories_15_1.png',
			name: 'Radiant Serpent Sett Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/exaltedsett.accessories_15_1.png'
		},
		{
			file: 'gold.png',
			name: 'Gold',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/gold.png'
		},
		{
			file: 'grandmaster.png',
			name: 'Grandmaster',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/grandmaster.png'
		},
		{
			file: 'halloflegends2024signaturebanner.accessories_14_12.png',
			name: 'Hall Of Legends 2024: Signature Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/halloflegends2024signaturebanner.accessories_14_12.png'
		},
		{
			file: 'hextech_banner.accessories_15_18.png',
			name: 'Hextech',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/hextech_banner.accessories_15_18.png'
		},
		{
			file: 'hol_relentless_hunter_banner.accessories_15_12.png',
			name: 'Hall of Legends 2025: Relentless Hunter Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/hol_relentless_hunter_banner.accessories_15_12.png'
		},
		{
			file: 'hol_signature_banner.accessories_15_12.png',
			name: 'Hall of Legends 2025: Signature Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/hol_signature_banner.accessories_15_12.png'
		},
		{
			file: 'iron.png',
			name: 'Iron',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/iron.png'
		},
		{
			file: 'lny2023.png',
			name: 'Lunar Revel 2023 Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/lny2023.png'
		},
		{
			file: 'master.png',
			name: 'Master',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/master.png'
		},
		{
			file: 'platinum.png',
			name: 'Platinum',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/platinum.png'
		},
		{
			file: 'sahnuzal_mordekaiser_banner.accessories_15_5.png',
			name: 'Sahn-Uzal Mordekaiser Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/sahnuzal_mordekaiser_banner.accessories_15_5.png'
		},
		{
			file: 'sf2023.png',
			name: 'Soul Fighter Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/sf2023.png'
		},
		{
			file: 'silver.png',
			name: 'Silver',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/silver.png'
		},
		{
			file: 'spirit_blossom_banner.accessories_15_9.png',
			name: 'Spirit Blossom Beyond Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/spirit_blossom_banner.accessories_15_9.png'
		},
		{
			file: 'spirit_blossom_morgana_banner.accessories_15_13.png',
			name: 'Spirit Blossom Morgana Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/spirit_blossom_morgana_banner.accessories_15_13.png'
		},
		{
			file: 'tempest_banner.accessories_15_18.png',
			name: 'Tempest',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/tempest_banner.accessories_15_18.png'
		},
		{
			file: 'trials_of_twilight_banner.accessories_15_17.png',
			name: 'Trials of Twilight Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/trials_of_twilight_banner.accessories_15_17.png'
		},
		{
			file: 'unkillabledemonkingbanner.accessories_14_12.png',
			name: 'Hall of Legends 2024: Unkillable Demon King',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/unkillabledemonkingbanner.accessories_14_12.png'
		},
		{
			file: 'wa2023.png',
			name: 'Winterblessed 2023 Aurora Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/wa2023.png'
		},
		{
			file: 'welcome_to_noxus_banner.accessories_15_1.png',
			name: 'Welcome to Noxus Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/welcome_to_noxus_banner.accessories_15_1.png'
		},
		{
			file: 'wn2023.png',
			name: 'Winterblessed 2023 Noble Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/wn2023.png'
		},
		{
			file: 'wr2023.png',
			name: 'Winterblessed 2023 Royal Banner',
			path: '/lol-game-data/assets/ASSETS/Regalia/BannerSkins/wr2023.png'
		}	
	];

  const CONFIG = {
    STYLE_ID: "regalia.banner-style",
    DATASTORE_KEY: "regalia.banner-datastore",
  };

  class RegaliaBanner {
    constructor() {
      this.buttonCreated = false;
      this.customButton = null;
      this.init();
    }

    async init() {
      try {
        this.applyCustomBanner();
        this.startButtonObserver();
      } catch (error) {}
    }

    startButtonObserver() {
      const checkInterval = setInterval(() => {
        const isBannerVisible = this.isBannerContainerVisible();
        const isPlayerVisible = this.isPlayerActive();
        
        if (isPlayerVisible) {
          this.applyCustomBanner();
        }
        
        if (isBannerVisible) {
          if (!this.buttonCreated) {
            this.customButton = this.createBannerButton();
            this.customButton.addEventListener('click', () => this.showBannerList());
            this.buttonCreated = true;
          }
        } else {
          if (this.buttonCreated && this.customButton) {
            document.body.removeChild(this.customButton);
            this.customButton = null;
            this.buttonCreated = false;
          }
        }
      }, 250);
    }

    isBannerContainerVisible() {
      const bannerContainer = document.querySelector('.identity-customizer-banner-wrapper');
      return bannerContainer && bannerContainer.offsetParent !== null;
    }

    isPlayerActive() {
      const lobbyContainer = document.querySelector('.v2-banner-component.local-player');
      const profileInfo = document.querySelector('.style-profile-summoner-info-component');
      
      return (lobbyContainer && lobbyContainer.offsetParent !== null) || 
             (profileInfo && profileInfo.offsetParent !== null);
    }

    createBannerButton() {
      const button = document.createElement('button');
      
      const img = document.createElement('img');
      img.src = '/fe/lol-uikit/images/icon_settings.png'
	  img.style.width = '15px';
      img.style.height = '15px';
      img.style.display = 'block';
      
      button.appendChild(img);
      button.style.position = 'fixed';
      button.style.bottom = '514px';
      button.style.right = '300px';
      button.style.zIndex = '9999';
      button.style.padding = '5px';
      button.style.backgroundColor = '#1e292c';
      button.style.border = '2px solid #81602b';
      button.style.borderRadius = '50%';
      button.style.cursor = 'pointer';
      button.style.width = '20px';
      button.style.height = '20px';
      button.style.display = 'flex';
      button.style.alignItems = 'center';
      button.style.justifyContent = 'center';
      button.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
      button.style.transition = 'all 0.3s ease';
      
      button.addEventListener('mouseenter', () => {
        button.style.backgroundColor = '#253236';
        button.style.transform = 'scale(1.1)';
        button.style.boxShadow = '0 4px 15px rgba(0,0,0,0.4)';
      });
      
      button.addEventListener('mouseleave', () => {
        button.style.backgroundColor = '#1e292c';
        button.style.transform = 'scale(1)';
        button.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
      });
      
      document.body.appendChild(button);
      return button;
    }

    revertBanner() {
      const styleElement = document.getElementById(CONFIG.STYLE_ID);
      if (styleElement) {
        styleElement.remove();
      }
    }

    async applyCustomBanner() {
      this.revertBanner();
      const selectedBanner = await window.DataStore.get(CONFIG.DATASTORE_KEY);

      if (!selectedBanner) {
        return;
      }

      const style = document.createElement("style");
      style.id = CONFIG.STYLE_ID;
      style.innerHTML = `
        .style-profile-summoner-info-component {
          --banner-image: url('assets/banner/${selectedBanner}') !important;
        }
        .challenges-identity-customizer-banner-container {
          --banner-image: url('assets/banner/${selectedBanner}') !important;
        }
        .v2-banner-component.local-player {
          --banner-image: url('assets/banner/${selectedBanner}') !important;
        }
      `;
      document.head.appendChild(style);
    }

    async getCurrentBanner() {
      return await window.DataStore.get(CONFIG.DATASTORE_KEY) || 'default.png';
    }

    async showBannerList() {
      const modal = document.createElement('div');
      modal.style.position = 'fixed';
      modal.style.top = '0';
      modal.style.left = '0';
      modal.style.width = '100%';
      modal.style.height = '100%';
      modal.style.backgroundColor = 'rgba(0,0,0,0.8)';
      modal.style.zIndex = '10000';
      modal.style.display = 'flex';
      modal.style.alignItems = 'center';
      modal.style.justifyContent = 'center';
      
      const content = document.createElement('div');
      content.style.backgroundColor = '#131312';
      content.style.padding = '30px';
      content.style.borderRadius = '15px';
      content.style.maxWidth = '1000px';
      content.style.width = '60%';
      content.style.maxHeight = '500px';
      content.style.height = '80%';
      content.style.overflow = 'hidden';
      content.style.boxShadow = '0 0 30px rgba(0,0,0,0.7)';
      content.style.position = 'relative';
      content.style.boxSizing = 'border-box';
      content.style.display = 'flex';
      content.style.flexDirection = 'column';
      
      const webkitScrollbarStyle = document.createElement('style');
      webkitScrollbarStyle.textContent = `
        #banner-list-content::-webkit-scrollbar {
          display: none;
        }
      `;
      document.head.appendChild(webkitScrollbarStyle);
      
      const closeBtn = document.createElement('button');
      closeBtn.style.position = 'absolute';
      closeBtn.style.top = '15px';
      closeBtn.style.right = '15px';
      closeBtn.style.width = '20px';
      closeBtn.style.height = '20px';
      closeBtn.style.backgroundColor = '#ff0267';
      closeBtn.style.borderRadius = '50%';
      closeBtn.style.cursor = 'pointer';
      closeBtn.style.display = 'flex';
      closeBtn.style.alignItems = 'center';
      closeBtn.style.justifyContent = 'center';
      
      closeBtn.addEventListener('mouseenter', () => {
        closeBtn.style.animation = 'ColorUp 0.3s forwards';
      });

      closeBtn.addEventListener('mouseleave', () => {
        closeBtn.style.animation = 'ColorDown 0.25s forwards';
      });
      
      closeBtn.addEventListener('click', () => {
        document.body.removeChild(modal);
        document.head.removeChild(webkitScrollbarStyle);
      });
      
      const reminder = document.createElement('div');
      reminder.style.color = '#ff0267';
      reminder.style.fontSize = '9px';
      reminder.style.fontWeight = 'bold';
      reminder.style.textAlign = 'right';
      reminder.style.marginBottom = '20px';
      reminder.style.padding = '10px';
      reminder.style.flexShrink = '0';
      reminder.textContent = 'REMEMBER: ONLY YOU CAN SEE CHANGES!';
	  reminder.className = 'soft-text-glow';
      
      const listContainer = document.createElement('div');
      listContainer.style.flex = '1';
      listContainer.style.overflowY = 'auto';
      listContainer.style.overflowX = 'hidden';
      listContainer.id = 'banner-list-content';
      
      const list = document.createElement('div');
      list.style.display = 'grid';
      list.style.gridTemplateColumns = 'repeat(auto-fill, minmax(120px, 1fr))';
      list.style.gap = '15px';
      list.style.width = '100%';
      list.style.boxSizing = 'border-box';
      
      BANNER_LIST.forEach(async (banner) => {
        const item = document.createElement('div');
        item.style.padding = '10px';
        item.style.backgroundColor = '#21211F';
        item.style.borderRadius = '8px';
        item.style.cursor = 'pointer';
        item.style.border = '2px solid transparent';
        item.style.display = 'flex';
        item.style.flexDirection = 'column';
        item.style.alignItems = 'center';
        item.style.gap = '8px';
        item.style.boxSizing = 'border-box';
        
        const bannerName = document.createElement('img');
        bannerName.src = banner.path;
        bannerName.alt = banner.name;
        bannerName.style.width = '100%';
        bannerName.style.height = '100%';
        bannerName.style.objectFit = 'cover';
        bannerName.style.borderRadius = '4px';
        bannerName.style.boxSizing = 'border-box';
        
        const currentBannerFile = await this.getCurrentBanner();
        
        if (banner.file === currentBannerFile) {
          bannerName.style.filter = 'grayscale(100%)';
          bannerName.style.transform = 'scale(1.05)';
          item.style.border = '2px solid #980841';
        }
        
        bannerName.addEventListener('mouseenter', () => {
          if (bannerName.file !== currentBannerFile) {
            bannerName.style.animation = 'scaleUp 0.3s forwards';
          }
        });

        bannerName.addEventListener('mouseleave', () => {
          if (bannerName.file !== currentBannerFile) {
            bannerName.style.animation = 'scaleDown 0.25s forwards';
          }
        });
        
        item.addEventListener('click', async () => {
          await window.DataStore.set(CONFIG.DATASTORE_KEY, banner.file);
          window.Toast.success(`Banner changed!`);
          await this.applyCustomBanner();
          document.body.removeChild(modal);
          document.head.removeChild(webkitScrollbarStyle);
        });
        
        item.appendChild(bannerName);
        list.appendChild(item);
      });
      
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          document.body.removeChild(modal);
          document.head.removeChild(webkitScrollbarStyle);
        }
      });
      
      const handleEscape = (e) => {
        if (e.key === 'Escape') {
          document.body.removeChild(modal);
          document.head.removeChild(webkitScrollbarStyle);
          document.removeEventListener('keydown', handleEscape);
        }
      };
      document.addEventListener('keydown', handleEscape);
      
      listContainer.appendChild(list);
      content.appendChild(closeBtn);
      content.appendChild(reminder);
      content.appendChild(listContainer);
      modal.appendChild(content);
      document.body.appendChild(modal);
      
      modal.addEventListener('DOMNodeRemoved', () => {
        document.removeEventListener('keydown', handleEscape);
        if (document.head.contains(webkitScrollbarStyle)) {
          document.head.removeChild(webkitScrollbarStyle);
        }
      });
    }
  }

  window.addEventListener("load", () => {
    window.RegaliaBanner = new RegaliaBanner();
  });
})();