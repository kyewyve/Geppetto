/**
* @author kye
* @link https://github.com/kyewyve/Geppetto
*/

(() => {
  const CONFIG = {
    STYLE_ID: "regalia-icon-styles",
    MODAL_ID: "regalia-icon-modal",
    DATASTORE_KEY: "regalia-icon.selected",
    API_URL: "https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/profile-icons.json",
  };

  function StopTimeProp(object, properties) {
    if (!object) return;
    for (const type in object) {
      if (
        (properties && properties.length && properties.includes(type)) ||
        !properties ||
        !properties.length
      ) {
        let value = object[type];
        try {
          Object.defineProperty(object, type, {
            configurable: false,
            get: () => value,
            set: (v) => v,
          });
        } catch {}
      }
    }
  }

  class RegaliaIcon {
    constructor() {
      this.summonerId = null;
      this.puuid = null;
      this.observer = null;
      this.buttonCreated = false;
      this.customButton = null;
      this.init();
    }

    async init() {
      try {
        try {
          const res = await fetch("/lol-summoner/v1/current-summoner");
          const data = await res.json();
          this.summonerId = data.summonerId;
          this.puuid = data.puuid;
        } catch (e) {}

        this.applyCustomIcon();
        this.IconContainerObserver();
      } catch (error) {}
    }
	
	IconContainerObserver() {
		const checkInterval = setInterval(() => {
			const isIconVisible = this.isIconContainerVisible();
			
			if (isIconVisible) {
				if (!this.buttonCreated) {
					this.customButton = this.createIconButton();
					this.customButton.addEventListener('click', () => this.showIconModal());
					this.buttonCreated = true;
				}
			} else {
				if (this.buttonCreated && this.customButton) {
					document.body.removeChild(this.customButton);
					this.customButton = null;
					this.buttonCreated = false;
				}
			}
		}, 250);
	}
	
	isIconContainerVisible() {
        const IconContainer = document.querySelector('.identity-customizer-icon-header');
        return IconContainer && IconContainer.offsetParent !== null;
    }
	
    createIconButton() {
        const button = document.createElement('button');
        
        const img = document.createElement('img');
		img.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAA7VBMVEVMaXHw5dLs49Hr69fv5tHw5tHp6dT////w5tLx59Dv5tHw5dL////s4s/w5tLx5Nbw5tLw5tLw5NDz6NL//7/x487w5dDv5dHw5tLw5dLv5dHw5dPw5dLv5dL/2trv5tLw5dLv5tH//6r/1NT//8zw5tLw5tLv5tHu5dTv5dHw5tLw5dHw5dHy5czv5tLv5dLw5tHu49Pv5NTy5tPv5tLw5tLw5dLt58/w5dHv5dLw5dHv5dHv5tLw5dHw5dLx6NHv5dLy5dLw5tLw5dLw5tLv5dHw5dHv5dHw5dHu6NHy5s7x5NHv5tHx5NDw5tLJd85WAAAATnRSTlMA8BwNh+EMAog3+asBG+QTw4lYFwQlR9bjeJdGeZUH69+oAwYFkLvsHuax4FkUp/riLzAppfXdK4yE8eimWo446ih+3uWAepjzLRUn7SaYSNMnAAABtklEQVR42u3X127CQBCF4bUxXptQAgmEGkoIJdT03nub93+cWMJHgDDZQUaCC/83SLvSh1jswYigoKD1iNxWC9WWBG1vWP9BVpLtELmStHOAcrYcrV0SJdnOSNKNIU00NHRn8ZUIEsdxpEQpAgJFSoknIkhKx+2DPLoi4kkSjrI3hWQxnfa3WIp0fSyQL+nhXCCuFDYK+q75mDGeaVz5U3BKnI6Zbg2rshsm9PPFgvKEDkJiIvOG0DvHaQ3IbV+KqaJ32Bm0GJBBbtWoQJCq2DPUjszifEwxk4lzykolZJPbrfAohV1bCRVpVMfzPWUHU0U5VpHFuMhYUEZ4llkYignPYgtDu8KzvaVBq/toBf5h+//6WRdkxfuCrCgvSHRPbineLeL/puWPkf7sGOlzxgjSI3MH2wV2IrpgVJo3ak8I5XnDv0konJJYlakwoWaCBaVfpn+OYvV6rGCc0TjNZjlxUsSTfuH4lRrESjtSQVs7LGgzJJhSu0welTWuAyme7uVnH/3yPVuDw5Icx3nVramDj1u6s2hrcDhSI43H4yKYIh6PbQ2O378Qh6bwC6E1gYKCgtaiPxxoRSc3vN5VAAAAAElFTkSuQmCC'
        img.style.width = '15px';
        img.style.height = '15px';
        img.style.display = 'block';
        
        button.appendChild(img);
        button.style.position = 'fixed';
        button.style.bottom = '515px';
        button.style.right = '350px';
        button.style.zIndex = '9999';
        button.style.padding = '5px';
        button.style.backgroundColor = '#1e292c';
        button.style.border = '2px solid #81602b';
        button.style.borderRadius = '50%';
        button.style.cursor = 'pointer';
        button.style.width = '20px';
        button.style.height = '20px';
        button.style.display = 'flex';
        button.style.alignItems = 'center';
        button.style.justifyContent = 'center';
        button.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
        button.style.transition = 'all 0.3s ease';
        
        button.addEventListener('mouseenter', () => {
            button.style.backgroundColor = '#253236';
            button.style.transform = 'scale(1.1)';
            button.style.boxShadow = '0 4px 15px rgba(0,0,0,0.4)';
        });
        
        button.addEventListener('mouseleave', () => {
            button.style.backgroundColor = '#1e292c';
            button.style.transform = 'scale(1)';
            button.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
        });
        
        
        document.body.appendChild(button);
        return button;
    }

    revertIcon() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      const styleElement = document.getElementById(CONFIG.STYLE_ID);
      if (styleElement) {
        styleElement.remove();
      }
    }

    async applyCustomIcon() {
      this.revertIcon();
      const selectedId = await window.DataStore.get(CONFIG.DATASTORE_KEY);

      if (!selectedId) {
        return;
      }

      const iconUrl = `/lol-game-data/assets/v1/profile-icons/${selectedId}.jpg`;

      const style = document.createElement("style");
      style.id = CONFIG.STYLE_ID;
      style.innerHTML = `
        :root { --custom-avatar: url("${iconUrl}"); }
        .top > .icon-image.has-icon, summoner-icon {
          content: var(--custom-avatar) !important;
        }
      `;
      document.head.appendChild(style);

      this.observeDOM();
    }

    observeDOM() {
      const updateAndFreezeIcon = (element) => {
        const iconElement = element.shadowRoot
          ?.querySelector("lol-regalia-crest-v2-element")
          ?.shadowRoot?.querySelector(".lol-regalia-summoner-icon");
        if (iconElement) {
          iconElement.style.backgroundImage = "var(--custom-avatar)";
          StopTimeProp(iconElement.style, ["backgroundImage"]);
          return;
        }

        if (element.tagName === "LOL-REGALIA-CREST-V2-ELEMENT") {
          const crestIcon = element.shadowRoot?.querySelector(
            ".lol-regalia-summoner-icon"
          );
          if (crestIcon) {
            crestIcon.style.backgroundImage = "var(--custom-avatar)";
            StopTimeProp(crestIcon.style, ["backgroundImage"]);
          }
        }
      };

      const selectors = [
        `lol-regalia-hovercard-v2-element[summoner-id="${this.summonerId}"]`,
        `lol-regalia-profile-v2-element[summoner-id="${this.summonerId}"]`,
        `lol-regalia-parties-v2-element[summoner-id="${this.summonerId}"]`,
        `lol-regalia-crest-v2-element[voice-puuid="${this.puuid}"]`,
      ];
      const combinedSelector = selectors.join(", ");

      this.observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (node instanceof Element) {
              if (node.matches(combinedSelector)) {
                updateAndFreezeIcon(node);
              }
              const matchingElements = node.querySelectorAll(combinedSelector);
              if (matchingElements.length > 0) {
                matchingElements.forEach(updateAndFreezeIcon);
              }
            }
          }
        }
      });

      this.observer.observe(document.body, { childList: true, subtree: true });
      const existingElements = document.querySelectorAll(combinedSelector);
      existingElements.forEach(updateAndFreezeIcon);
    }

    async showIconModal() {
      document.getElementById(CONFIG.MODAL_ID)?.remove();

      const modal = document.createElement('div');
      modal.id = CONFIG.MODAL_ID;
      modal.style.position = 'fixed';
      modal.style.top = '0';
      modal.style.left = '0';
      modal.style.width = '100%';
      modal.style.height = '100%';
      modal.style.backgroundColor = 'rgba(0,0,0,0.8)';
      modal.style.zIndex = '10000';
      modal.style.display = 'flex';
      modal.style.alignItems = 'center';
      modal.style.justifyContent = 'center';
      
      const content = document.createElement('div');
      content.style.backgroundColor = '#131312';
      content.style.padding = '30px';
      content.style.borderRadius = '15px';
      content.style.maxWidth = '1000px';
      content.style.width = '60%';
      content.style.maxHeight = '500px';
      content.style.height = '80%';
      content.style.overflow = 'hidden';
      content.style.boxShadow = '0 0 30px rgba(0,0,0,0.7)';
      content.style.position = 'relative';
      content.style.boxSizing = 'border-box';
      content.style.display = 'flex';
      content.style.flexDirection = 'column';
      
      const reminder = document.createElement('div');
      reminder.style.color = '#ff0267';
      reminder.style.fontSize = '14px';
      reminder.style.fontWeight = 'bold';
      reminder.style.textAlign = 'center';
      reminder.style.marginBottom = '20px';
      reminder.style.padding = '10px';
      reminder.textContent = 'REMEMBER: ONLY YOU CAN SEE CHANGES!';
      content.appendChild(reminder);
      
      const closeBtn = document.createElement('button');
      closeBtn.style.position = 'absolute';
      closeBtn.style.top = '15px';
      closeBtn.style.right = '15px';
      closeBtn.style.width = '20px';
      closeBtn.style.height = '20px';
      closeBtn.style.backgroundColor = '#ff0267';
      closeBtn.style.borderRadius = '50%';
      closeBtn.style.cursor = 'pointer';
      closeBtn.style.display = 'flex';
      closeBtn.style.alignItems = 'center';
      closeBtn.style.justifyContent = 'center';
      closeBtn.style.border = 'none';
      closeBtn.style.outline = 'none';
      closeBtn.innerHTML = '';
      
      closeBtn.addEventListener('mouseenter', () => {
        closeBtn.style.transform = 'scale(1.1)';
        closeBtn.style.backgroundColor = '#ff1a75';
      });

      closeBtn.addEventListener('mouseleave', () => {
        closeBtn.style.transform = 'scale(1)';
        closeBtn.style.backgroundColor = '#ff0267';
      });
      
      closeBtn.addEventListener('click', () => {
        document.body.removeChild(modal);
      });
      
      const listContainer = document.createElement('div');
      listContainer.style.flex = '1';
      listContainer.style.overflowY = 'auto';
      listContainer.style.overflowX = 'hidden';
      listContainer.style.marginTop = '20px';
      listContainer.style.paddingRight = '20px';
      
      const scrollbarStyle = document.createElement('style');
      scrollbarStyle.textContent = `
        .regalia-icon-scrollable::-webkit-scrollbar {
          width: 10px;
        }
        .regalia-icon-scrollable::-webkit-scrollbar-track {
          background: #21211F;
          border-radius: 10px;
          margin: 5px;
        }
        .regalia-icon-scrollable::-webkit-scrollbar-thumb {
          background: #ff0267;
          border-radius: 10px;
          border: 2px solid #21211F;
        }
        .regalia-icon-scrollable::-webkit-scrollbar-thumb:hover {
          background: #ff1a75;
        }
      `;
      document.head.appendChild(scrollbarStyle);
            
      const list = document.createElement('div');
      list.style.display = 'grid';
      list.style.gridTemplateColumns = 'repeat(auto-fill, minmax(120px, 1fr))';
      list.style.gap = '15px';
      list.style.width = '100%';
      list.style.boxSizing = 'border-box';
      list.style.overflow = 'visible';

      listContainer.appendChild(list);
      content.appendChild(closeBtn);
      content.appendChild(listContainer);
      modal.appendChild(content);
      document.body.appendChild(modal);

      listContainer.className = 'regalia-icon-scrollable';

      this.loadIconsIntoModal(list, modal);

      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          document.body.removeChild(modal);
        }
      });
      
      const handleEscape = (e) => {
        if (e.key === 'Escape') {
          document.body.removeChild(modal);
          document.removeEventListener('keydown', handleEscape);
        }
      };
      document.addEventListener('keydown', handleEscape);
      
      modal.addEventListener('DOMNodeRemoved', () => {
        document.removeEventListener('keydown', handleEscape);
      });
    }

    async loadIconsIntoModal(list, modal) {
      try {
        const response = await fetch(CONFIG.API_URL);
        const icons = await response.json();
        
        list.innerHTML = '';

        const validIcons = [];
        const currentIconId = await window.DataStore.get(CONFIG.DATASTORE_KEY);
        
        const iconPromises = icons
          .sort((a, b) => b.id - a.id)
          .filter((icon) => icon.id !== -1)
          .map((icon) => {
            return new Promise((resolve) => {
              const img = new Image();
              img.onload = () => {
                validIcons.push({ 
                  ...icon, 
                  element: img
                });
                resolve();
              };
              img.onerror = () => {
                resolve();
              };
              img.src = `/lol-game-data/assets/v1/profile-icons/${icon.id}.jpg`;
              img.style.width = '100%';
              img.style.height = '100%';
              img.style.objectFit = 'cover';
              img.style.borderRadius = '4px';
              img.style.boxSizing = 'border-box';
            });
          });

        await Promise.all(iconPromises);

        validIcons.forEach(icon => {
          const item = document.createElement('div');
          item.style.padding = '10px';
          item.style.backgroundColor = '#21211F';
          item.style.borderRadius = '8px';
          item.style.cursor = 'pointer';
          item.style.border = '2px solid transparent';
          item.style.display = 'flex';
          item.style.flexDirection = 'column';
          item.style.alignItems = 'center';
          item.style.gap = '8px';
          item.style.boxSizing = 'border-box';
          
          const iconImg = icon.element.cloneNode(true);
          
          if (icon.id === currentIconId) {
            iconImg.style.filter = 'grayscale(100%)';
            iconImg.style.transform = 'scale(1.05)';
            item.style.border = '2px solid #980841';
          }
          
          iconImg.addEventListener('mouseenter', () => {
            if (icon.id !== currentIconId) {
              iconImg.style.animation = 'scaleUp 0.3s ease forwards';
            }
          });

          iconImg.addEventListener('mouseleave', () => {
            if (icon.id !== currentIconId) {
              iconImg.style.animation = 'scaleDown 0.25s ease forwards';
            }
          });
          
          item.addEventListener('click', async () => {
            await window.DataStore.set(CONFIG.DATASTORE_KEY, icon.id);
            window.Toast.success(`Icon changed!`);
            await this.applyCustomIcon();
            document.body.removeChild(modal);
          });
          
          item.appendChild(iconImg);
          list.appendChild(item);
        });

        if (validIcons.length === 0) {
          list.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px;"><p style="color: #e63946; font-size: 16px; margin: 0;">No valid icons found. Please try again later.</p></div>';
        }
      } catch (error) {
        list.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px;"><p style="color: #e63946; font-size: 16px; margin: 0;">Failed to load icons. Please try again later.</p></div>';
      }
    }
  }

  window.addEventListener("load", () => {
    window.RegaliaIcon = new RegaliaIcon();
  });
})();