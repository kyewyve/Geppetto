After enabling the plugin, you just need to go to the profile settings and click on the background change.

<img width="248" height="94" alt="image" src="https://github.com/user-attachments/assets/9cea3344-95db-48e9-a726-ac1f6bda0c7e" />
